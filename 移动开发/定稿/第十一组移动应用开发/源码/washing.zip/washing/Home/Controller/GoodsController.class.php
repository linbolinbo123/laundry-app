<?php
namespace Home\Controller;
use Think\Controller;
class GoodsController extends Controller {
    function showlist(){
        echo "列表展示ing";
    }
    function detail(){
        $this->display();
    } 
}