<?php
namespace Home\Controller;
use Think\Controller;
class UserController extends Controller {
    function login(){
        $this->display();
    }
    /**
     * 用户注册功能
     */
    function register(){
        $user = new \Model\UserModel();
        if(!empty($_POST)){
            //1.获取提交表单,进行表单验证，并存入数据库
            $data = $user->create();
            if($data) {
                $data['user_hobby'] = implode(',', $data['user_hobby']);
                $z = $user->add($data);
                if($z){
                    $this->redirect('login', array(), 2, '注册成功，2秒后跳转到登录页面');
                }else{
                    $this->redirect('register', array(), 2, '注册失败。');
                }
                echo 'success';
            } else {
                //验证失败，查看失败信息
                $this->assign('errorInfo',$user->getError());
            }
            
        }
//        else{
            //2.展示注册页面
            $this->display();
//        }
    } 
}