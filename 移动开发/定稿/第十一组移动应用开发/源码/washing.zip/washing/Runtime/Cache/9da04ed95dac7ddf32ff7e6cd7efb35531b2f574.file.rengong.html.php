<?php /* Smarty version Smarty-3.1.6, created on 2018-05-31 10:40:04
         compiled from "E:/phpStudy/WWW/ThinkPHP/washing/Admin/View\Dingdan\rengong.html" */ ?>
<?php /*%%SmartyHeaderCode:217185afe7e618f8129-89849024%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9da04ed95dac7ddf32ff7e6cd7efb35531b2f574' => 
    array (
      0 => 'E:/phpStudy/WWW/ThinkPHP/washing/Admin/View\\Dingdan\\rengong.html',
      1 => 1527734397,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '217185afe7e618f8129-89849024',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_5afe7e6193a7b',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5afe7e6193a7b')) {function content_5afe7e6193a7b($_smarty_tpl) {?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
    <head>
        <meta http-equiv=content-type content="text/html; charset=utf-8" />
        <link href="<?php echo @ADMIN_CSS_URL;?>
admin.css" type="text/css" rel="stylesheet" />
    </head>
    <body>
    <form action="<?php echo @__SELF__;?>
" method="post">
        <table cellspacing=0 cellpadding=0 width="60%" align=center border=0>
            <tr height=28>
                <td>订单号： </td>
                <td><input type="text" name="dingdan_id"></td>
            </tr>
            <tr height=28>
                <td>客户id： </td>
                <td><input type="text" name="user_id"></td>
            </tr>
            <tr height=28>
                <td>客户姓名： </td>
                <td><input type="text" name="user_name"></td>
            </tr>
            <tr height=28>
                <td>客户电话： </td>
                <td><input type="text" name="user_tel"></td>
            </tr>
            <tr height=28>
                <td>客户地址： </td>
                <td><input type="text" name="user_add"></td>
            </tr>
            <tr height=28>
                <td>预计取件时间： </td>
                <td><input type="datetime" name="qujian_time"></td>
            </tr>
            <tr height=28>
                <td>预计送达时间： </td>
                <td><input type="datetime" name="songda_time"></td>
            </tr>
            <tr height=28>
                <td>重估重量： </td>
                <td><input type="text" name="weight">KG</td>
            </tr>
            <tr height=28>
                <td>重估费用： </td>
                <td><input type="text" name="price"></td>
            </tr>
            <tr height=28>
                <td></td>
                <td><input type="submit" value="添加订单消息"> </td>
            </tr>
        </table>
    </form>
        
    </body>
</html><?php }} ?>