<?php /* Smarty version Smarty-3.1.6, created on 2018-05-31 13:57:09
         compiled from "E:/phpStudy/WWW/ThinkPHP/washing/Admin/View\Dingdan\upd.html" */ ?>
<?php /*%%SmartyHeaderCode:279455afe90ad4c5700-39291429%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '39cbede3cf7a2865c48cad341d5be86c93810a7a' => 
    array (
      0 => 'E:/phpStudy/WWW/ThinkPHP/washing/Admin/View\\Dingdan\\upd.html',
      1 => 1527744143,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '279455afe90ad4c5700-39291429',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_5afe90ad50fa9',
  'variables' => 
  array (
    'dingdan' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5afe90ad50fa9')) {function content_5afe90ad50fa9($_smarty_tpl) {?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
    <head>
        <meta http-equiv=content-type content="text/html; charset=utf-8" />
        <link href="<?php echo @ADMIN_CSS_URL;?>
admin.css" type="text/css" rel="stylesheet" />
    </head>
    <body>
        <form action="<?php echo @__SELF__;?>
" method="post">
        <table cellspacing=0 cellpadding=0 width="60%" align=center border=0>
            <tr height=28>
                <td>订单信息：<?php echo $_smarty_tpl->tpl_vars['dingdan']->value['dingdan_id'];?>
 </td>
            </tr>
            <tr height=28>
                <td>预计取件时间：<?php echo date("Y-m-d H:i",$_smarty_tpl->tpl_vars['dingdan']->value['qujian_time']);?>
 </td>
            </tr>
            <tr height=28>
                <td>预计送达时间：<?php echo date("Y-m-d H:i",$_smarty_tpl->tpl_vars['dingdan']->value['songda_time']);?>
 </td>
            </tr>
            <tr height=28>
                <td>重估重量：<?php echo $_smarty_tpl->tpl_vars['dingdan']->value['weight'];?>
 </td>
            </tr>
            <tr height=28>
                <td>重估费用：<?php echo $_smarty_tpl->tpl_vars['dingdan']->value['price'];?>
 </td>
            </tr>
            <tr height=28>
                <td>
                    <select name="state" style="width: 100px;">
                        <option selected="selected" value="0">请选择</option>
                        <option value="1">待取件</option>
                        <option value="2">待送件</option>
                        <option value="3">已完成</option>
                    </select>
                </td>
            </tr>
            <tr height=28>
                <td>
                    <input type="hidden" value="<?php echo $_smarty_tpl->tpl_vars['dingdan']->value['dingdan_id'];?>
" name="dingdan_id"/>
                    <input type="submit" value="确认修改" align="center">
                </td>
            </tr>
        </table>
    </form>
        
    </body>
</html><?php }} ?>