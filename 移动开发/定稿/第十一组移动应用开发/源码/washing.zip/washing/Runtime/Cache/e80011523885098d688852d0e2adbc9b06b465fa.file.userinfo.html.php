<?php /* Smarty version Smarty-3.1.6, created on 2018-05-31 14:41:29
         compiled from "E:/phpStudy/WWW/ThinkPHP/washing/Admin/View\Dingdan\userinfo.html" */ ?>
<?php /*%%SmartyHeaderCode:304005afe93b1185f71-46673556%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e80011523885098d688852d0e2adbc9b06b465fa' => 
    array (
      0 => 'E:/phpStudy/WWW/ThinkPHP/washing/Admin/View\\Dingdan\\userinfo.html',
      1 => 1527748883,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '304005afe93b1185f71-46673556',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_5afe93b11d418',
  'variables' => 
  array (
    'users' => 0,
    'v' => 0,
    'pagelist' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5afe93b11d418')) {function content_5afe93b11d418($_smarty_tpl) {?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
    <head>
        <meta http-equiv="content-type" content="text/html; charset=UTF-8" />

        <title>会员列表</title>

        <link href="<?php echo @ADMIN_CSS_URL;?>
mine.css" type="text/css" rel="stylesheet" />
    </head>
    <body>
        <style>
            .tr_color{ background-color: #9F88FF }
        </style>
        <div class="div_head">
            <span>
                <span style="float: left;">当前位置是：人员管理-》人员列表</span>
            </span>
            <span style="float: right; margin-right: 8px; font-weight: bold;">
                    <a style="text-decoration: none;" href="<?php echo @__CONTROLLER__;?>
/tianjia">【添加人员】</a>
                </span>
        </div>
        <div></div>
        <div style="font-size: 13px; margin: 10px 5px;">
            <table class="table_a" border="1" width="100%">
                <tbody><tr style="font-weight: bold;">
                        <td>用户名</td>
                        <td>联系电话</td>
                        <td align="center">用户类型</td>
                        <td align="center">操作</td>
                    </tr>
                    <?php  $_smarty_tpl->tpl_vars['v'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['v']->_loop = false;
 $_smarty_tpl->tpl_vars['k'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['users']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['v']->key => $_smarty_tpl->tpl_vars['v']->value){
$_smarty_tpl->tpl_vars['v']->_loop = true;
 $_smarty_tpl->tpl_vars['k']->value = $_smarty_tpl->tpl_vars['v']->key;
?>
                    <tr id="product1">
                        <td><?php echo $_smarty_tpl->tpl_vars['v']->value['user_name'];?>
</td>
                        <td><?php echo $_smarty_tpl->tpl_vars['v']->value['user_tel'];?>
</td>
                        <?php if ($_smarty_tpl->tpl_vars['v']->value['user_type']==0){?>
                        <td>普通用户</td>
                        <?php }?>
                        <?php if ($_smarty_tpl->tpl_vars['v']->value['user_type']==1){?>
                        <td>跑腿人员</td>
                        <?php }?>
                        <?php if ($_smarty_tpl->tpl_vars['v']->value['user_type']==2){?>
                        <td>店铺人员</td>
                        <?php }?>
                        <td><a href="<?php echo @__CONTROLLER__;?>
/deleteuser/user_id/<?php echo $_smarty_tpl->tpl_vars['v']->value['user_id'];?>
">删除</a></td>
                    </tr>
                    <?php } ?>
                    <tr>
                        <td colspan="20" style="text-align: center;">
                            <?php echo $_smarty_tpl->tpl_vars['pagelist']->value;?>

                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </body>
</html><?php }} ?>