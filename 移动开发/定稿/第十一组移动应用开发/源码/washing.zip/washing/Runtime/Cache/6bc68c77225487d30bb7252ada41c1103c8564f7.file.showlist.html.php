<?php /* Smarty version Smarty-3.1.6, created on 2018-05-31 14:42:38
         compiled from "E:/phpStudy/WWW/ThinkPHP/washing/Admin/View\Dingdan\showlist.html" */ ?>
<?php /*%%SmartyHeaderCode:274425afe82131ff3c6-88521857%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6bc68c77225487d30bb7252ada41c1103c8564f7' => 
    array (
      0 => 'E:/phpStudy/WWW/ThinkPHP/washing/Admin/View\\Dingdan\\showlist.html',
      1 => 1527748101,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '274425afe82131ff3c6-88521857',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_5afe821333ba8',
  'variables' => 
  array (
    'dingdans' => 0,
    'v' => 0,
    'pagelist' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5afe821333ba8')) {function content_5afe821333ba8($_smarty_tpl) {?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
    <head>
        <meta http-equiv="content-type" content="text/html; charset=UTF-8" />

        <title>会员列表</title>

        <link href="<?php echo @ADMIN_CSS_URL;?>
mine.css" type="text/css" rel="stylesheet" />
    </head>
    <body>
        <style>
            .tr_color{ background-color: #9F88FF }
        </style>
        <div class="div_head">
            <span>
                <span style="float: left;">当前位置是：订单管理-》订单列表</span>
            </span>
        </div>
        <div></div>
        <div class="div_search">
            <span>
                <form action="#" method="get">
                    输入日期查询订单
                    <input type="text" />
                    <input value="查询" type="submit" />
                </form>
                
            </span>
            <span>
                <form action="#" method="get">
                    输入月份查询订单
                    <input type="text" />
                    <input value="查询" type="submit" />
                </form>
            </span>
            
        </div>
        <div style="font-size: 13px; margin: 10px 5px;">
            <table class="table_a" border="1" width="100%">
                <tbody><tr style="font-weight: bold;">
                        <td>订单号</td>
                        <td>下单时间</td>
                        <td>取件时间</td>
                        <td>送达时间</td>
                        <td>重量</td>
                        <td>洗涤费用</td>
                        <td>总费用</td>
                        <td>订单状态</td>
                        <td align="center" colspan="2">备注</td>
                    </tr>
                    <?php  $_smarty_tpl->tpl_vars['v'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['v']->_loop = false;
 $_smarty_tpl->tpl_vars['k'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['dingdans']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['v']->key => $_smarty_tpl->tpl_vars['v']->value){
$_smarty_tpl->tpl_vars['v']->_loop = true;
 $_smarty_tpl->tpl_vars['k']->value = $_smarty_tpl->tpl_vars['v']->key;
?>
                    <tr id="product1">
                        <td><?php echo $_smarty_tpl->tpl_vars['v']->value['dingdan_id'];?>
</td>
                        <td><?php echo date("Y-m-d H:i",$_smarty_tpl->tpl_vars['v']->value['dingdan_time']);?>
</td>
                        <td><?php echo date("Y-m-d H:i",$_smarty_tpl->tpl_vars['v']->value['qujian_time']);?>
</td>
                        <td><?php echo date("Y-m-d H:i",$_smarty_tpl->tpl_vars['v']->value['songda_time']);?>
</td>
                        <td><?php echo $_smarty_tpl->tpl_vars['v']->value['weight'];?>
</td>
                        <td><?php echo $_smarty_tpl->tpl_vars['v']->value['washing_price'];?>
</td>
                        <td><?php echo $_smarty_tpl->tpl_vars['v']->value['price'];?>
</td>
                        <td><?php echo $_smarty_tpl->tpl_vars['v']->value['state'];?>
</td>
                        <td><a href="<?php echo @__CONTROLLER__;?>
/upd/goods_id/<?php echo $_smarty_tpl->tpl_vars['v']->value['goods_id'];?>
">修改</a></td>
                        <td><a href="<?php echo @__CONTROLLER__;?>
/deletedingdan/dingdan_id/<?php echo $_smarty_tpl->tpl_vars['v']->value['dingdan_id'];?>
" >删除</a></td>
                    </tr>
                    <?php } ?>
                    <tr>
                        <td colspan="20" style="text-align: center;">
                            总订单数：
                            总重量：
                            总洗涤费：
                            总送取费：
                        </td>
                    </tr>
                    <tr>
                        <td colspan="20" style="text-align: center;">
                            <?php echo $_smarty_tpl->tpl_vars['pagelist']->value;?>

                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </body>
</html><?php }} ?>