<?php /* Smarty version Smarty-3.1.6, created on 2018-05-31 16:55:45
         compiled from "E:/phpStudy/WWW/ThinkPHP/washing/Admin/View\Dingdan\paotui.html" */ ?>
<?php /*%%SmartyHeaderCode:300545afe8e9a7e4d00-71470408%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd9f3f7b33e814ccbd3afed03802ca79c3883a09f' => 
    array (
      0 => 'E:/phpStudy/WWW/ThinkPHP/washing/Admin/View\\Dingdan\\paotui.html',
      1 => 1527756575,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '300545afe8e9a7e4d00-71470408',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_5afe8e9a836d9',
  'variables' => 
  array (
    'paotuis' => 0,
    'v' => 0,
    'user_id' => 0,
    'state' => 0,
    'dingdan_id' => 0,
    'pagelist' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5afe8e9a836d9')) {function content_5afe8e9a836d9($_smarty_tpl) {?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
    <head>
        <meta http-equiv="content-type" content="text/html; charset=UTF-8" />

        <title>会员列表</title>

        <link href="<?php echo @ADMIN_CSS_URL;?>
mine.css" type="text/css" rel="stylesheet" />
    </head>
    <body>
        <style>
            .tr_color{ background-color: #9F88FF }
        </style>
        <div class="div_head">
            <span>
                <span style="float: left;">当前位置是：人员管理-》空闲派送员列表</span>
            </span>
        </div>
        <div></div>
        <div style="font-size: 13px; margin: 10px 5px;">
            <table class="table_a" border="1" width="100%">
                <tbody><tr style="font-weight: bold;">
                        <td>用户名</td>
                        <td>联系电话</td>
                        <td align="center">指派</td>
                    </tr>
                    <?php  $_smarty_tpl->tpl_vars['v'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['v']->_loop = false;
 $_smarty_tpl->tpl_vars['k'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['paotuis']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['v']->key => $_smarty_tpl->tpl_vars['v']->value){
$_smarty_tpl->tpl_vars['v']->_loop = true;
 $_smarty_tpl->tpl_vars['k']->value = $_smarty_tpl->tpl_vars['v']->key;
?>
                    <tr id="product1">
                        <td><?php echo $_smarty_tpl->tpl_vars['v']->value['user_name'];?>
</td>
                        <td><?php echo $_smarty_tpl->tpl_vars['v']->value['user_tel'];?>
</td>
                        <td><a href="<?php echo @__CONTROLLER__;?>
/pub/user_id/<?php echo $_smarty_tpl->tpl_vars['user_id']->value;?>
/state/<?php echo $_smarty_tpl->tpl_vars['state']->value;?>
/paotui_id/<?php echo $_smarty_tpl->tpl_vars['v']->value['user_id'];?>
/dingdan_id/<?php echo $_smarty_tpl->tpl_vars['dingdan_id']->value;?>
" onclick="delete_product(1)">指派任务</a></td>
                    </tr>
                    <?php } ?>
                    <tr>
                        <td colspan="20" style="text-align: center;">
                            <?php echo $_smarty_tpl->tpl_vars['pagelist']->value;?>

                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </body>
</html><?php }} ?>