<?php /* Smarty version Smarty-3.1.6, created on 2018-05-03 10:49:05
         compiled from "E:/phpStudy/WWW/ThinkPHP/shop/Admin/View\Index\index.html" */ ?>
<?php /*%%SmartyHeaderCode:168895aea7130193c37-22062848%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '84efe048b83a636d46f835cb0b6f3cc83dfc72d9' => 
    array (
      0 => 'E:/phpStudy/WWW/ThinkPHP/shop/Admin/View\\Index\\index.html',
      1 => 1525315742,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '168895aea7130193c37-22062848',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_5aea71301d244',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5aea71301d244')) {function content_5aea71301d244($_smarty_tpl) {?><!doctype html public "-//w3c//dtd xhtml 1.0 frameset//en" "http://www.w3.org/tr/xhtml1/dtd/xhtml1-frameset.dtd">
<html>
    <head>
        <meta http-equiv=content-type content="text/html; charset=utf-8" />
        <meta http-equiv=pragma content=no-cache />
        <meta http-equiv=cache-control content=no-cache />
        <meta http-equiv=expires content=-1000 />
        
        <title>管理中心 v1.0</title>
    </head>
    <frameset border=0 framespacing=0 rows="60, *" frameborder=0>
        <frame name=head src="<?php echo @__CONTROLLER__;?>
/head.html" frameborder=0 noresize scrolling=no>
            <frameset cols="170, *">
                <frame name=left src="<?php echo @__CONTROLLER__;?>
/left.html" frameborder=0 noresize />
                <frame name=right src="<?php echo @__CONTROLLER__;?>
/right.html" frameborder=0 noresize scrolling=yes />
            </frameset>
    </frameset>
    <noframes>
    </noframes>
</html><?php }} ?>