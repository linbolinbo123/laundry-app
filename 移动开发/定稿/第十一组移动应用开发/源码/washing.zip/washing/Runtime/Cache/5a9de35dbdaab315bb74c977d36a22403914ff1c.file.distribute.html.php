<?php /* Smarty version Smarty-3.1.6, created on 2018-05-10 15:03:07
         compiled from "E:/phpStudy/WWW/ThinkPHP/shop/Admin/View\Role\distribute.html" */ ?>
<?php /*%%SmartyHeaderCode:121775af2af689ef853-08798596%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5a9de35dbdaab315bb74c977d36a22403914ff1c' => 
    array (
      0 => 'E:/phpStudy/WWW/ThinkPHP/shop/Admin/View\\Role\\distribute.html',
      1 => 1525935782,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '121775af2af689ef853-08798596',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_5af2af68a6c87',
  'variables' => 
  array (
    'role_id' => 0,
    'authinfoA' => 0,
    'v' => 0,
    'role_auth_info' => 0,
    'authinfoB' => 0,
    'vv' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5af2af68a6c87')) {function content_5af2af68a6c87($_smarty_tpl) {?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
    <head>
        <meta http-equiv="content-type" content="text/html; charset=UTF-8" />

        <title>会员列表</title>

        <link href="<?php echo @ADMIN_CSS_URL;?>
mine.css" type="text/css" rel="stylesheet" />
    </head>
    <body>
        <style>
            .tr_color{ background-color: #9F88FF }
        </style>
        <div class="div_head">
            <span>
                <span style="float: left;">当前位置是：角色管理-》角色列表</span>
                <span style="float: right; margin-right: 8px; font-weight: bold;">
                    <a style="text-decoration: none;" href="<?php echo @__CONTROLLER__;?>
/tianjia">【添加角色】</a>
                </span>
            </span>
        </div>
        <div></div>
        <form action="<?php echo @__SELF__;?>
/role_id/<?php echo $_smarty_tpl->tpl_vars['role_id']->value;?>
" method="POST">
            <table border="1" width="100%"  class="talbe_a">
            <?php  $_smarty_tpl->tpl_vars['v'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['v']->_loop = false;
 $_smarty_tpl->tpl_vars['k'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['authinfoA']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['v']->key => $_smarty_tpl->tpl_vars['v']->value){
$_smarty_tpl->tpl_vars['v']->_loop = true;
 $_smarty_tpl->tpl_vars['k']->value = $_smarty_tpl->tpl_vars['v']->key;
?>
            <tr>
                <td width="18%">
                    <input type="checkbox" name="auth_id[]" value="<?php echo $_smarty_tpl->tpl_vars['v']->value['auth_id'];?>
"
                           <?php if (in_array($_smarty_tpl->tpl_vars['v']->value['auth_id'],$_smarty_tpl->tpl_vars['role_auth_info']->value)){?>checked='checked'<?php }?>
                           />
                    <?php echo $_smarty_tpl->tpl_vars['v']->value['auth_name'];?>
</td>
                <td>
                    <?php  $_smarty_tpl->tpl_vars['vv'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['vv']->_loop = false;
 $_smarty_tpl->tpl_vars['kk'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['authinfoB']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['vv']->key => $_smarty_tpl->tpl_vars['vv']->value){
$_smarty_tpl->tpl_vars['vv']->_loop = true;
 $_smarty_tpl->tpl_vars['kk']->value = $_smarty_tpl->tpl_vars['vv']->key;
?>
                    <?php if ($_smarty_tpl->tpl_vars['vv']->value['auth_pid']==$_smarty_tpl->tpl_vars['v']->value['auth_id']){?>
                    <div  style="width: 200px;float: left">
                        <input type="checkbox" name="auth_id[]" value="<?php echo $_smarty_tpl->tpl_vars['vv']->value['auth_id'];?>
"
                           <?php if (in_array($_smarty_tpl->tpl_vars['vv']->value['auth_id'],$_smarty_tpl->tpl_vars['role_auth_info']->value)){?>checked='checked'<?php }?>
                           />
                        <?php echo $_smarty_tpl->tpl_vars['vv']->value['auth_name'];?>

                    </div>
                    <?php }?>
                    <?php } ?>
                </td>
            </tr>
            <?php } ?>
        </table>
            <input type="submit" value="提交"/>
        </form>
    </body>
</html><?php }} ?>