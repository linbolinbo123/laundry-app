<?php /* Smarty version Smarty-3.1.6, created on 2018-05-18 16:50:27
         compiled from "E:/phpStudy/WWW/ThinkPHP/washing/Admin/View\Dingdan\chargeset.html" */ ?>
<?php /*%%SmartyHeaderCode:291485afe93d3254cb0-18091915%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a64ecb8d83be5baf6456840433ad5976895eaebc' => 
    array (
      0 => 'E:/phpStudy/WWW/ThinkPHP/washing/Admin/View\\Dingdan\\chargeset.html',
      1 => 1526633385,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '291485afe93d3254cb0-18091915',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_5afe93d329734',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5afe93d329734')) {function content_5afe93d329734($_smarty_tpl) {?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
    <head>
        <meta http-equiv=content-type content="text/html; charset=utf-8" />
        <link href="<?php echo @ADMIN_CSS_URL;?>
admin.css" type="text/css" rel="stylesheet" />
    </head>
    <body>
    <form>
        <table cellspacing=0 cellpadding=0 width="60%" align=center border=0>
            <tr height=28>
                <td>修改取送费用 </td>
                <td><input type="text">/次</td>
            </tr>
            <tr height=28>
                <td>修改洗涤费用 </td>
                <td><input type="text">/KG</td>
            </tr>
            
            <tr height=28>
                <td></td>
                <td><input type="submit" value="确认修改"> </td>
            </tr>
        </table>
    </form>
        
    </body>
</html><?php }} ?>