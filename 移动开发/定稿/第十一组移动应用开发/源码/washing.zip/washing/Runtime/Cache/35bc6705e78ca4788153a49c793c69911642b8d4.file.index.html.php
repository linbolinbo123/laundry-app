<?php /* Smarty version Smarty-3.1.6, created on 2018-05-18 14:13:11
         compiled from "E:/phpStudy/WWW/ThinkPHP/washing/Admin/View\Index\index.html" */ ?>
<?php /*%%SmartyHeaderCode:91455afe6ef7340525-21873288%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '35bc6705e78ca4788153a49c793c69911642b8d4' => 
    array (
      0 => 'E:/phpStudy/WWW/ThinkPHP/washing/Admin/View\\Index\\index.html',
      1 => 1525315742,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '91455afe6ef7340525-21873288',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_5afe6ef73c524',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5afe6ef73c524')) {function content_5afe6ef73c524($_smarty_tpl) {?><!doctype html public "-//w3c//dtd xhtml 1.0 frameset//en" "http://www.w3.org/tr/xhtml1/dtd/xhtml1-frameset.dtd">
<html>
    <head>
        <meta http-equiv=content-type content="text/html; charset=utf-8" />
        <meta http-equiv=pragma content=no-cache />
        <meta http-equiv=cache-control content=no-cache />
        <meta http-equiv=expires content=-1000 />
        
        <title>管理中心 v1.0</title>
    </head>
    <frameset border=0 framespacing=0 rows="60, *" frameborder=0>
        <frame name=head src="<?php echo @__CONTROLLER__;?>
/head.html" frameborder=0 noresize scrolling=no>
            <frameset cols="170, *">
                <frame name=left src="<?php echo @__CONTROLLER__;?>
/left.html" frameborder=0 noresize />
                <frame name=right src="<?php echo @__CONTROLLER__;?>
/right.html" frameborder=0 noresize scrolling=yes />
            </frameset>
    </frameset>
    <noframes>
    </noframes>
</html><?php }} ?>