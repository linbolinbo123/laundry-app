<?php /* Smarty version Smarty-3.1.6, created on 2018-05-31 15:21:38
         compiled from "E:/phpStudy/WWW/ThinkPHP/washing/Admin/View\Dingdan\tianjia.html" */ ?>
<?php /*%%SmartyHeaderCode:49785afe9584df8856-85990043%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '64aa518f8b93af585a92dba246145557d12cef80' => 
    array (
      0 => 'E:/phpStudy/WWW/ThinkPHP/washing/Admin/View\\Dingdan\\tianjia.html',
      1 => 1527751074,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '49785afe9584df8856-85990043',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_5afe9584e525e',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5afe9584e525e')) {function content_5afe9584e525e($_smarty_tpl) {?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
    <head>
        <title>添加商品</title>
        <meta http-equiv="content-type" content="text/html;charset=utf-8">
        <link href="<?php echo @ADMIN_CSS_URL;?>
mine.css" type="text/css" rel="stylesheet">
    </head>

    <body>

        <div class="div_head">
            <span>
                <span style="float:left">当前位置是：人员管理-》添加人员信息</span>
                <span style="float:right;margin-right: 8px;font-weight: bold">
                    <a style="text-decoration: none" href="<?php echo @__CONTROLLER__;?>
/showlist">【返回】</a>
                </span>
            </span>
        </div>
        <div></div>

        <div style="font-size: 13px;margin: 10px 5px">
            <form action="<?php echo @__SELF__;?>
" method="post" enctype="multipart/form-data">
            <table border="1" width="100%" class="table_a">
                <tr>
                    <td>用户名</td>
                    <td><input type="text" name="user_name" /></td>
                </tr>
                <tr>
                    <td>电话</td>
                    <td><input type="text" name="user_tel" /></td>
                </tr>
                <tr>
                    <td>人员类型</td>
                    <td>
                    <select name="user_type" style="width: 100px;">
                        <option selected="selected" value="3">请选择</option>
                        <option value="2">店铺人员</option>
                        <option value="1">跑腿员</option>
                    </select>
                    </td>
                </tr>
                
                <tr>
                    <td colspan="2" align="center">
                        <input type="submit" value="添加">
                    </td>
                </tr>  
            </table>
            </form>
        </div>
    </body>
</html><?php }} ?>