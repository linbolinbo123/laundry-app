<?php

namespace Admin\Controller;
use Tools\AdminController;
class IndexController extends AdminController {
    function index(){
        $this->display();
    }
    function head(){
        $this->display();
    }
    function left(){
        //从session中获取登录管理员的id
        $admin_id = session('admin_id');
        //实例化manager对象，获取登录的管理员信息
        $manager_info = D('manager')->find($admin_id);
        //通过管理员信息的mg_role_id获取管理员角色信息
        $role_info = D('role')->find($manager_info['mg_role_id']);
        //判断是否为管理员，若是拥有全部权限
        if($manager_info['mg_name'] == 'admin') {
            $auth_infoA = D('auth')->where("auth_level=0")->select();
            $auth_infoB = D('auth')->where("auth_level=1")->select();
            $this->assign('auth_infoA',$auth_infoA);
            $this->assign('auth_infoB',$auth_infoB);
            $this->display();
        }else{
            //通过管理员的角色信息的roles_auth_ids字段获取管理员的权限信息
            //分为顶级权限和次顶级权限
            $auth_ids = $role_info['role_auth_ids'];
            $auth_infoA = D('auth')->where("auth_level=0 AND auth_id IN ($auth_ids)")->select();
            $auth_infoB = D('auth')->where("auth_level=1 AND auth_id IN ($auth_ids)")->select();
            //将获取到的权限信息放到视图模板中
            $this->assign('auth_infoA',$auth_infoA);
            $this->assign('auth_infoB',$auth_infoB);
            $this->display();
        }
        
    }
    function right(){
        $this->display();
    }
}

