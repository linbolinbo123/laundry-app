<?php
namespace Admin\Controller;
use Tools\AdminController;
use Think\Verify;
class ManagerController extends AdminController {
    /*
     * 登录功能
     */
    function login(){
        //获取表单数据
        //dump($_POST);
        if(!empty($_POST)) {
            //检验验证码是否正确
            $verify = new Verify();
            if($verify->check($_POST['captcha'])){
                //校验用户名密码
                $userpwd = array(
                    'mg_name' => $_POST['admin_user'],
                    'mg_pwd' => $_POST['admin_psd'],
                );
                $info = D('manager')->where($userpwd)->find();
                if($info){
                    //session持久化
                    session('admin_name',$info['mg_name']);
                    session('admin_id', $info['mg_id']);
                    $this->redirect('Index/index');
                }else {
                    $this->redirect('login', array(), 2, '用户名或密码错误！');
                }
                    
            }else {
                $this->redirect('login', array(), 2, '验证码错误！');
            }
        }else{
            $this->display();
        }
    }
    /*
     * 验证码生成
     */
    function verifyImg() {
        $cfg = array(
            'imageH'    =>  40,                   // 验证码图片高度
            'imageW'    =>  100,                  // 验证码图片宽度
            'fontSize'  =>  15,
            'length'    =>  4,                    // 验证码位数
            'fontttf'   =>  '4.ttf',              // 验证码字体，不设置随机获取
        );
        //实例化Verify对象
        $verify = new \Think\Verify($cfg);
        $verify->entry();
    }
    /*
     * 退出登录功能
     */
    function logout() {
        //清除session,跳转到登录页面
        session(null);
        $this->redirect('Manager/login');
    }
}