<?php

namespace Admin\Controller;
use Tools\AdminController;
use Tools\phpMQTT;
class DingdanController extends AdminController {
    //人工订单
    function rengong() {
        if(!empty($_POST)) {
            //创建订单对象
            $dingdanModel = D('dingdan');
            //获取表单提交上来的数据
            $qujian_time = strtotime($_POST['qujian_time']);
            $songda_time = strtotime($_POST['songda_time']);
            $data = $dingdanModel->create();
            $data['qujian_time'] = $qujian_time;
            $data['songda_time'] = $songda_time;
            $data['dingdan_time'] = time();
            $data['washing_price'] = $_POST['weight']*10;
            $data['price'] = $_POST['price'];
            $data['user_name'] = $_POST['user_name'];
            $data['user_tel'] = $_POST['user_tel'];
            $data['user_add'] = $_POST['user_add'];
            //创建用户对象
            $userModel = D('washinguser');
            //获取表单提交数据
            $user = $userModel->create();
            echo "<pre>";
//            var_dump($data);
//            var_dump($user);
//            echo "</pre>";
//            exit;
            if($dingdanModel->add($data)){
                if($userModel->add($user)) {
                    echo "添加成功";
                }
            }
        }else{
            //载入视图模板
            $this->display();
        }
    }
    //订单查询
    function showlist() {
        //获取所有订单信息
        //1.创建订单模型对象
        $dingdansModel = D('dingdan');
        //2.查询订单
        $dingdans = $dingdansModel->select();
        //3.将获取的数据放入视图中
        $this->assign('dingdans',$dingdans);
    	//载入视图模板
    	$this->display();
    }
    //服务调度页面
    function service() {
        //获取未完成订单信息
        //1.创建订单模型对象
        $dingdansModel = D('dingdan');
        //2.查询订单
        $dingdans = $dingdansModel->where('state!=0')->select();
        //3.将获取的数据放入视图中
        $this->assign('dingdans',$dingdans);
    	//载入视图模板
    	$this->display();
    }
    //指派派送员
    function paotui($user_id,$state,$dingdan_id) {
        
        //获取跑腿人员信息
        //1.创建跑腿模型对象,查询跑腿人员
        $paotuis = D('washinguser')->where('user_type=1')->select();
        //2.将获取的跑腿人员数据放入视图
        $this->assign('paotuis',$paotuis);
        $this->assign('user_id',$user_id);
        $this->assign('dingdan_id',$dingdan_id);
        $this->assign('state',$state);
    	//载入视图模板
    	$this->display();
    }
    //修改订单状态
    function upd($dingdan_id) {
        if(!empty($_POST)) {
            $state = $_POST['state'];
            $dingdan_id = $_POST['dingdan_id'];
            $sql = "UPDATE sw_dingdan SET state=$state WHERE dingdan_id = $dingdan_id";
            $dingdanModel = D('dingdan');
            $z = $dingdanModel->execute($sql);
            if($z) {
                $this->redirect('service', array(), 2, '修改成功！');
            }else {
                $this->redirect('upd', array('dingdan' =>$dingdan_id), 2, '修改失败！');
            }
        }else{
            $dingdan = D('dingdan')->where("dingdan_id=$dingdan_id")->find();
            $this->assign('dingdan',$dingdan);
            //载入视图模板
            $this->display();
        }
        
    }

    //用户信息页面
    function userinfo() {
        //获取所有用户信息
        //1.创建订单模型对象
        $userModel = D('washinguser');
        //2.查询订单
        $users = $userModel->select();
        //3.将获取的数据放入视图中
        $this->assign('users',$users);
    	//载入视图模板
    	$this->display();
    }
    //费用设置页面

    function chargeset() {

    	//载入视图模板
    	$this->display();
    }

    //添加店铺或者跑腿人员
    function tianjia() {
        if(!empty($_POST)) {
            $userModel = D('washinguser');
            $user = $userModel->create();
            $user['user_id'] = rand(0, 999);
            if($userModel->add($user)) {
                $this->redirect('userinfo', array(), 2, '添加成功！');
            }else {
                $this->redirect('tianjia', array(), 2, '添加失败！');
            }
        }else {
            //载入视图模板
            $this->display();
        }
    	
    }
    //发布用户信息到跑腿端
    function pub($paotui_id,$user_id,$state,$dingdan_id) {
        //通过获取上来的参数，获取用户相应的信息
        //1.创建普通用户模型对象,并获取所需要的值
        $dingdaninfo = D('dingdan')->field('qujian_time,songda_time,price')->where("dingdan_id=$dingdan_id")->find();
        $userinfo=D('washinguser')->field('user_name,user_tel,user_add')->where("user_id=$user_id")->find();
        $info = array_merge($dingdaninfo,$userinfo);
        $info['state'] = $state;
//        echo "<pre>";
//        var_dump($info);
//        echo "</pre>";
//        exit();
        $zhuti = $paotui_id;
        $content = json_encode($info);
//        var_dump($zhuti);
//        var_dump($test);
//        exit;
        $server = "10.50.165.118";     // 服务代理地址(mqtt服务端地址)
        $port = 1883;                     // 通信端口
        $username = "";                   // 用户名(如果需要)
        $password = "";                   // 密码(如果需要
        $client_id = uniqid(); // 设置你的连接客户端id
        $mqtt = new phpMQTT($server, $port, $client_id); //实例化MQTT类
        if ($mqtt->connect(true, NULL, $username, $password)) {
            //如果创建链接成功
            $mqtt->publish($zhuti, $content, 0);
            // 发送到 xxx3809293670ctr 的主题 一个信息 内容为 setr=3xxxxxxxxx Qos 为 0 
            $mqtt->close();    //发送后关闭链接
            $this->redirect('service', array(), 2, '发送成功！');
        } else {
            echo "Time out!\n";
        }
        
    }
    //删除订单
    function deletedingdan($dingdan_id) {
        $del = D('dingdan')->where("dingdan_id=$dingdan_id")->delete();
        if($del) {
            $this->redirect("showlist", array(), 2, '删除成功！');
        }else {
            $this->redirect('showlist', array(), 2, '删除失败！');
        }
    }
    function deleteuser($user_id) {
        $del = D('washinguser')->where("user_id=$user_id")->delete();
        if($del) {
            $this->redirect("userinfo", array(), 2, '删除成功！');
        }else {
            $this->redirect('userinfo', array(), 2, '删除失败！');
        }
    }

}

