<?php
namespace Model;
use Think\Model;
//用户模型
class UserModel extends Model {
    //制定验证规则
    //是否批处理验证
    protected $patchValidate = true;
    //自动验证定义
    protected $_validate = array(
        //用户名不为空
        array('username','require','用户名不能为空'),
        array('username','','用户名已被占用',0,'unique'),
        //密码不能为空
        array('password','require','密码不能为空'),
        //确认密码不能为空且必须与密码一致
        array('password2','require','确认密码不能为空'),
        array('password2','password','两次密码不一致',0,'confirm'),
        //邮箱格式验证  
        array('user_email','email','邮箱格式不正确',2),
        //QQ好验证
        array('user_qq','5,12','qq号长度不正确',0,'length'),
        //学历验证
        array('user_xueli','2,3,4,5','请选择您的学历',0,'in'),
        //爱好两个以上
        array('user_hobby','check_hobby','爱好至少选择两个',1,'callback'),
        
        

    );
    function check_hobby($arr) {
        if(count($arr)<2){
            return false;
        }
        return true;
    }
}

