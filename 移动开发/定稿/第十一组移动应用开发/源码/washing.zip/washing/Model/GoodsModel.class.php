<?php
namespace Model;
use Think\Model;
//商品模型
class GoodsModel extends Model {
    
}

