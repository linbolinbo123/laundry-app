<?php
namespace Model;
use Think\Model;
//商品模型
class EnglishModel extends Model {
    //定义当前model操作的真实数据表名
    protected $trueTableName = 'english';
}

