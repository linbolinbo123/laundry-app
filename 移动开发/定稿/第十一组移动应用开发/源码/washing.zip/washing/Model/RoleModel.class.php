<?php
namespace Model;
use Think\Model;
//商品模型
class RoleModel extends Model {
    //建一个方法用来处理数据与更新数据
    function saveAuth($role_id,$authids) {
        //将传过来的权限id数组（一维数组）转换成字符串
        $auth_ids_str = implode(',', $authids);
        //根据$auth_id_str查找对应的控制器-操作方法
        //创建一个auth对象
        $auth = D('auth');
        $authinfo = $auth->select($auth_ids_str);
        //得到的$authinfo是二维数组,遍历并进行判断
        $s = "";
        foreach ($authinfo as $k => $v) {
            if(!empty($v['auth_c']) && !empty($v['auth_a'])) {
                $s .= $v['auth_c']."-".$v['auth_a'].",";
            }
        }
        
        $s = rtrim($s,',');
        $sql = "UPDATE sw_role set role_auth_ids='$auth_ids_str',role_auth_ac='$s' WHERE role_id='$role_id'";
        $z = $this->execute($sql);
        return $z;
    }
}

