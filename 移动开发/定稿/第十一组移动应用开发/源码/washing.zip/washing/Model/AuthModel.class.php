<?php
namespace Model;
use Think\Model;
//商品模型
class AuthModel extends Model {
    //定义一个方法对表单数据进行处理
    function saveData($data) {
        //上传的数据缺少全路径和层级
        //1.处理全路径问题
        //先把获取到的数据插入数据库，才能获得此行数据的id值
        $new_id = D('auth')->add($data);
        //获取父级权限的全路径值,而如果是顶级权限，则全路径为0
        if($data['auth_pid'] == 0) {
            $path = 0;
        }else{
            $p_info = $this->find($data['auth_pid']);
            $p_path = $p_info['auth_path'];
            $path = $p_path."-".$new_id;
        }
        //2.获取层级问题（多种方法，可以根据全路径中的“-”数）
        $level = substr_count($path, '-');
        $sql = "UPDATE sw_auth SET auth_path='$path',auth_level='$level' WHERE auth_id='$new_id'";
        return $this->execute($sql);
        
    }
}

