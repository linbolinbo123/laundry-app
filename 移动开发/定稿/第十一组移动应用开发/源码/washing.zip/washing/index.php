<?php
//设置header，避免憨子乱码
header("content-type:text/html;charset=utf-8");
//设置模式
define("APP_DEBUG", true);//开发调试模式
//定义前台常量
define('CSS_URL', '/washing/Home/Public/css/');
define('IMG_URL', '/washing/Home/Public/images/');
define('IMG_JS', '/washing/Home/Public/js/');
//定义后台常量
define('ADMIN_CSS_URL', '/washing/Admin/Public/css/');
define('ADMIN_IMG_URL', '/washing/Admin/Public/img/');
define('ADMIN_JS_URL', '/washing/Admin/Public/js/');
//引入tp框架的接口文件
include("../ThinkPHP/ThinkPHP.php");
?>