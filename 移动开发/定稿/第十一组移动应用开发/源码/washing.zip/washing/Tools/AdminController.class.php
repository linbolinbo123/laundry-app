<?php

namespace Tools;
use Think\Controller;
class AdminController extends Controller {
    function __construct() {
        //先继承父类的构造方法，否则会覆盖
        parent::__construct();
        
        //用户访问权限的控制
        //1.获取当前正在访问的控制器方法
        $now_ac = CONTROLLER_NAME."-".ACTION_NAME;
        //2.从SESSION中获取登录的用户信息
        $admin_id = session('admin_id');
        //根据获得的id，获取该用户的信息，并获取其对应的角色id
        $admin_info = D('manager')->find($admin_id);
        $admin_role_id = $admin_info['mg_role_id'];
        //根据获得的角色id，获取该用户的角色信息
        $admin_role = D('role')->find($admin_role_id);
        //获取该角色的控制器-操作方法权限列表
        $auth_str = $admin_role['role_auth_ac'];
        
        //注意，有一些基本操作的控制器和操作方法在管理员用户中是没有进行访问限制的，需要考虑进去
        $allow_ac = "Index-index,Index-head,Index-left,Index-right,Manager-login,Manager-logout,Manager-verifyImg";
   
        //注意，超级管理员不属于任何一个分组，所以权限信息为空，需要另行判断
        //从session中获取用户的名称
        $admin_name = session('admin_name');
        
        //注意，另一种情况，用户未登录（或者session过期），访问的是管理员表的第一个数据
        //用户未登录，上面获取的用户名称为空
        //为了避免陷入死循环，定义一个未登录时默认允许访问的控制器操作方法列表
//        $z = empty($admin_name);
//        dump($admin_name);
        $un_logined_allow_ac = "Manager-login,Manager-verifyImg";
        if(empty($admin_name) && strpos($un_logined_allow_ac, $now_ac)===FALSE){
            //将其跳转到登录页面
//            $this->redirect('Manager/login');
            $js=<<<eof
                    <script type="text/javascript">
                    window.top.location.href="/washing/index.php/Admin/Manager/login";
                    </script>
eof;
            echo $js;
        }
        
        //判断当前正在访问的控制器方法是否在该角色允许访问的控制器操作方法之内
        //判断当前正在访问的控制器方法是否在默认允许访问的控制器操作方法之内
        //判断该用户是否为超级管理员
        if(strpos($auth_str, $now_ac)===FALSE && strpos($allow_ac, $now_ac)===FALSE && 
                $admin_name!='admin') {
            exit('对不起，您没有访问权限！');
        }
    }
}

